# woRLdle

[woRLdle](https://hmeleiro.shinyapps.io/woRLdle/) is a wordle-like game with country border silhouettes. The [original idea](https://worldle.teuteuf.fr/) is from [Teuteuf](https://github.com/teuteuf). I just re-developed the game in an R shiny app for fun and to play more than once a day.